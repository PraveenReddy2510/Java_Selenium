package com.actitime.pageclasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage extends BasePage{
	
	public LoginPage(WebDriver driver)
	{
		super(driver);
	}
	
	@FindBy(how=How.ID, using="username") 
	private WebElement usernameTB;

	@FindBy(how=How.NAME, using="pwd")
	private WebElement passwordTB;
	
	@FindBy(how=How.ID, using="loginButton")
	private WebElement loginButton;
	
	@FindBy(how=How.XPATH, using="//span[@class='errormsg' and not(@id='errorSpan')]")
	private WebElement errorMessage;

	public HomePage navigateToHomePage(String username, String password)
	{
		usernameTB.sendKeys(username);
		passwordTB.sendKeys(password);
		loginButton.click();
		
		return new HomePage(this.driver);
	}
	
	public String getErrorMessge() {
		return errorMessage.getText();
	}
	
	public void enterUsername(String username){
		usernameTB.sendKeys(username);
	}
	
	public void enterPassword(String password) {
		passwordTB.sendKeys(password);
	}
	
	public void clickLoginButton() {
		loginButton.click();
	}
}
