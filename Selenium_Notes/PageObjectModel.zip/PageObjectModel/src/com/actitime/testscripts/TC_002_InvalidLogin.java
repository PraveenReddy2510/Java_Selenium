package com.actitime.testscripts;

import com.actitime.pageclasses.LoginPage;

public class TC_002_InvalidLogin {
	public static void main(String[] args) {
		BaseTest.launchBrowser();
		LoginPage login = new LoginPage(BaseTest.driver);
		login.enterUsername("adminss");
		login.enterPassword("nasdhgasdf");
		login.clickLoginButton();
		
		String errorMessage = login.getErrorMessge();
		
		if(errorMessage.contains("Username or Password is invalid. Please try again.")) {
			System.out.println("PASS: Error message is displaying");
		}else {
			System.out.println("FAIL: Error message is not displaying");
		}
		
		BaseTest.closeBrowser();
	}
}
