package com.actitime.pageclasses;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {

	WebDriver driver;
	public BasePage(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
		this.driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	}
	
	@FindBy(how=How.ID, using="logoutLink")
	private WebElement logoutLink;
	
	public void logout()
	{
		logoutLink.click();
	}
	
	public Boolean verifyTitle(String title) {
	Boolean isTitle = false;
	try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		isTitle = wait.until(ExpectedConditions.titleContains(title));
		return isTitle;
	} catch (TimeoutException e) {
		System.out.println(e);
		return isTitle;
	}
}

}
