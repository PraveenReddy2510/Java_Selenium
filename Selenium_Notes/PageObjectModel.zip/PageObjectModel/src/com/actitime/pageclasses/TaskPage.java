package com.actitime.pageclasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TaskPage extends BasePage{

	public TaskPage(WebDriver driver)
	{
		super(driver);
	}
	
	@FindBy(xpath="//div[text()='Add New Task']")
	private WebElement addNewTaskButton;
	
	@FindBy(xpath="//div[text()='Create new tasks']")
	private WebElement createNewTaskButton;
	
	public void clickOnCreateNewTask()
	{
		addNewTaskButton.click();
		createNewTaskButton.click();
	}
}
