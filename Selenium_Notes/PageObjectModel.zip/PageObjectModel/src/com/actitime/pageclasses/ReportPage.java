package com.actitime.pageclasses;

import org.openqa.selenium.WebDriver;

public class ReportPage extends BasePage {
	public ReportPage(WebDriver driver)
	{
		super(driver);
	}
}
