package com.actitime.testscripts;

import com.actitime.pageclasses.HomePage;
import com.actitime.pageclasses.LoginPage;

public class TC_001_ValidLogin {
	public static void main(String[] args) {
		BaseTest.launchBrowser();
		LoginPage login = new LoginPage(BaseTest.driver);
		HomePage home = login.navigateToHomePage("admin", "manager");
		
		Boolean isTrue = home.verifyTitle("Enter Time-Track");
		if(isTrue) {
			System.out.println("PASS: Home page is displayed");
		}else {
			System.out.println("FAIL: Home page is not displayed");
		}
		login.logout();
		BaseTest.closeBrowser();
	}
}