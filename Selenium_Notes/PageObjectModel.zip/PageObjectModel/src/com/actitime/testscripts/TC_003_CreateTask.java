package com.actitime.testscripts;

import com.actitime.pageclasses.HomePage;
import com.actitime.pageclasses.LoginPage;
import com.actitime.pageclasses.TaskPage;

public class TC_003_CreateTask {
	public static void main(String[] args) {
		BaseTest.launchBrowser();
		LoginPage login = new LoginPage(BaseTest.driver);
		HomePage home = login.navigateToHomePage("admin", "manager");
		TaskPage task = home.navigateToTaskPage();
		task.clickOnCreateNewTask();
		
		/*
		 * 
		 * Write a code to create the task
		 * 
		 */
		
		
		task.logout();
		BaseTest.closeBrowser();
	}
}
